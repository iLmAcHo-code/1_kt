﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lr13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                double Z = 0;
                int p = Convert.ToInt32(textBoxp.Text);
                int n = Convert.ToInt32(textBox3.Text);
                int N = Convert.ToInt32(textBoxN.Text);
                int R = Convert.ToInt32(textBoxR.Text);
                int b = Convert.ToInt32(textBoxb.Text);
                int c = Convert.ToInt32(textBoxc.Text);


                if (radioButton1.Checked)
                {
                    int znam = 2;
                    for (int i = 2; i < n; i++)
                    {
                        double chisl;
                        if (i % 2 == 0)
                        {
                            chisl = Math.Pow(p, i) * (-1);
                        }
                        else
                        {
                            chisl = Math.Pow(p, i);
                        }
                        Z += chisl / znam;
                        znam = znam * (i + 1);
                    }
                    textBoxZ.Text = Z.ToString();
                }
                if (radioButton2.Checked)
                {
                    for (int i = 1; i < N; i++)
                    {
                        for (int j = 1; j < R; j++)
                        {
                            Z += (Math.Pow(i, 2) + (b * j)) / (c * Math.Pow(i, 3));
                        }
                    }
                    textBoxZ.Text = Z.ToString();
                }
                
            }
            catch (FormatException ex)
            {
                MessageBox.Show("Пожалуйста, введите в поля целые числа! Иначе программа работать не будет!");
            }
        }
    }
}
