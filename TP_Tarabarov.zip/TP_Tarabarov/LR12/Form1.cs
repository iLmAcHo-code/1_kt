﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LR12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        float f, w, inp_e, inp_t;
        double The_t;
                
        private void textBoxE_TextChanged(object sender, EventArgs e)
        {
            try
            {
                inp_e = System.Convert.ToSingle(textBoxE.Text);
                The_t = GetValue(f, w, inp_e, inp_t);
                Text = GetTitleResult(The_t);
            }

            catch
            {
                Text = "ERROR";
            }
        }     

        private void textBoxT_TextChanged(object sender, EventArgs e)
        {
            try
            {
                inp_t = System.Convert.ToSingle(textBoxT.Text);
                The_t = GetValue(f, w, inp_e, inp_t);
                Text = GetTitleResult(The_t);
            }

            catch
            {
                Text = "ERROR";
            }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            f = e.X;
            w = e.Y;
            The_t = GetValue(f, w, inp_e, inp_t);
            Text = GetTitleResult(The_t);

            textBoxF.Text = e.X.ToString();
            textBoxW.Text = e.Y.ToString();
        }

        double GetValue(float f, float w, float e, float t)
        {
            double result = Math.Log10(f) - e + Math.Abs(Math.Sin(w / t) + Math.Sqrt(Math.Abs(e)));
            return result;
        }

        string GetTitleResult(double X)
        {
            if (Double.IsInfinity(X) || Double.IsNaN(X))
            {
                return "ERROR";
            }
            else
            {
                return string.Format("t = {0:0.00}", X);
            }
        }


    }
}
